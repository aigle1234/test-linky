---
name: Issue
about: Signaler un bug, demander une fonctionnalité, ou poser une question
title: ''
labels: ''
assignees: ''
---

<!--
Si votre question concerne Home Assistant, l'add-on HA-Linky, la configuration... vous êtes au bon endroit !

En revanche, si votre question concerne la création d'un token Conso API ou la récupération de données (problèmes de serveur, réponse d'Enedis, etc...), il s'agit d'un problème avec Conso API, je vous invite donc à créer une issue là-bas: https://github.com/bokub/conso-api/issues
-->
